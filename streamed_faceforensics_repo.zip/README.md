# Streamed FaceForensics++ Sample (Colab Ready)

This repository contains a Colab-ready notebook that:
- Streams a sample dataset (FaceForensics++-style) directly from Hugging Face.
- Trains and evaluates a lightweight CNN.
- Requires **no local storage or dataset downloads**.
- Designed for **resource-constrained environments** (Colab, JupyterLite, etc.)

## 🔗 Open in Colab
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/YOUR_USERNAME/streamed-faceforensics-demo/blob/main/Streamed_FaceForensics_Colab.ipynb)

## 📁 Contents
- `Streamed_FaceForensics_Colab.ipynb` – Main notebook
